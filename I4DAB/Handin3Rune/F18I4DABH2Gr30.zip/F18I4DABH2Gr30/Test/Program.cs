﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessLogic;
using BusinessLogic.Models;

namespace Test
{
	class Program
	{
		static void Main(string[] args)
		{
			
			using (var unitOfWork = new UnitOfWork(new ApplicationContext()))
			{
				var phones = unitOfWork.PhoneNumberRepo.GetAll();
				var persons = unitOfWork.PersonRepo.GetAll();
				unitOfWork.PhoneNumberRepo.RemoveRange(phones);
				unitOfWork.PersonRepo.RemoveRange(persons);
				unitOfWork.Complete();
				
				Person person = new Person
				{
					FirstName = "Jens",
					MiddleName = "Kjeld",
					LastName = "Larsen",
					Email = "JKL@minmail.dk",
					PersonType = "co-worker",
					PhoneNumbers = new List<PhoneNumber>()
					{
						new PhoneNumber()
						{
							Number = "12345678",
							PhoneType = "Home",
							Provider = "TDC"
						},
						new PhoneNumber()
						{
							Number = "87654321",
							PhoneType = "Work",
							Provider = "Telia"
						}
					},
					PrimaryAddress = new PrimaryAddress
					{
						Street = "Ringgaden",
						StreetNumber = "154A"
					}
				};
				

				unitOfWork.PersonRepo.Add(person);
				unitOfWork.Complete();
			}
		}
	}
}
