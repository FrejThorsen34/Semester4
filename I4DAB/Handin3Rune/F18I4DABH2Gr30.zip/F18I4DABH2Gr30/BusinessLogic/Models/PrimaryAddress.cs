﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic.Models
{
	public class PrimaryAddress : BaseModel
	{
		public string Street { get; set; }
		public string StreetNumber { get; set; }
		//public Zip Zip { get; set; }
		//public string ZipId { get; set; }
		//public virtual Person Person { get; set; }
		//public virtual int PersonId { get; set; }
	}
}
